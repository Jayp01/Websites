
        <?php
if(isset($_POST['submit'])){
        echo "you are successfully logged in!";
    if(isset($_POST["uname"])){
        $username=$_POST["uname"];
    }else{
        $username=" ";
    }
    if(isset($_POST["psw"])){
        $password=$_POST["psw"];
    }else{
        $password=" ";
    }
}
    else{
 $username=" ";       
    $password=" ";
    }
    echo "{$username}:{$password}";
    ?>
