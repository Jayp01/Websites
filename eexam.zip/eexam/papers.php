<!DOCTYPE html>
<html>
<style>
    *{
        font-family: Constantia;
    }
    .header{
	text-align:center;
	border-style: ridge;
        border-color: black;
background-color:orange;
	color:blue;
        width:25%;

}.header:hover{
        background-color: lightcoral;
    color:black;}
    .circle-block{
        border:1px solid black;
        border-style: ridge;
        border-radius: 100px;
        width:10%;
        background-color: lavenderblush;
        color:blue;
        padding:2px;
    
    }
    ul.topnav {
    list-style-type:none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color:lightcoral;
    border:1px solid black;
        width:40%;

}

    ul.topnav li {
 float:left;
        border-right: 1px solid black;
    }

ul.topnav li a {
    display:inline-block;
    color: white;
    text-align: center;
    padding: 14px 14px;
    font-size: 18px;
    text-decoration: none;

}

ul.topnav li a:hover:not(.active) {background-color:lightskyblue;
color:black;}

ul.topnav li a.active {background-color:lightgreen
;
color:black;}

ul.topnav li.right {float: right;}

@media screen and (max-width: 600px){
    ul.topnav li.right,
    ul.topnav li {float: none;}
}
    .logout{
     border-style:ridge;
        border:1px solid black;
    width:16%;
        background-color: limegreen;
     padding:5px;
    
    }
    .logout a{
        text-decoration: none;
    font-size: 18px;
    color:black;
    
    }
    .logout:hover{
        background-color:deepskyblue;
        color:white;
    }
    .course{
        background-color:coral;
        width:30%;
        padding:10px 8px;
        color:darkblue;
        font-size:24px;
    }
body{
background-image:url('http://vinsys.in/wp-content/uploads/2013/07/vinsys-it-services-worldwide-trainings.jpg');
    background-repeat:no-repeat;
    background-size:cover;
    background-color:blueviolet;}
    </style>
    
    <body><center><div class="header"><h1>TEST YOUR SKILLS!</h1></div> </center>
    <br/><ul class="topnav">
                <li><a  class="active" href="#home">Home</a></li>
                <li><a href="exam.htm">Exam Info</a></li>
               <li><a href="login1.htm">Login</a></li>
             <li><a href="register.htm">Sign Up</a></li>
             <li><a href="result.htm">Results</a></li>
                <li><a href="contact.htm">Contacts</a></li>
        </ul><br/>
        <div class="logout"><a href="home.htm">log out</a></div>
            <h2 style="font-size:24px;color:yellow">Which exam you wish to take?</h2>
   <div class="course">
       <ul class="courselist" style="list-style-type:disc">
            <li><a href="c.htm">C</a></li>
            <li><a href="c++.htm">C++</a></li>
            <li><a href="java.htm">Java</a></li>
            <li><a href="dbms.htm">DBMS</a></li>
        </ul>
    </div>
</body>
</html>