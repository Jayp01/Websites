<?php
$dbhost="localhost";
$dbuser="username";
$dbpsw="password";
$dbname="eexam";
$connection=mysqli_connect($dbhost,$dbuser,$dbpsw,$dbname);

if(mysqli_connect_errno())
{
    die("databse connection failed").mysqli_connect_error()."".mysqli_connect_errno();
}
?>















<!DOCTYPE html>
<html>
<style>
    *{
        font-family: basic;
    }
    .header{
	text-align: center;
	border-style: ridge;
	border-color: black;
	background-color:orange;
	color:blue;
        width:25%;

}

body{
background-image:url('http://vinsys.in/wp-content/uploads/2013/07/vinsys-it-services-worldwide-trainings.jpg');
color: white;
    background-repeat: no-repeat;
    background-position:center;
    background-size: cover;
    }
form {
    border: 1px solid black;
	background-color:palevioletred;
	width:25%;
    color:black;
}

input[type=text], input[type=password] {
    width: 75%;
    padding: 5px 5px;
    margin: 1px 0;
    display: inline-block;
    border: 1px solid black;
    box-sizing: border-box;
	font-size:18px;
    
    }input[type=text]:focus{
        background-color: lightcyan;
    }input[type=password]:focus{
        background-color: lightcyan;
    }

button {
    background-color: dodgerblue;
    color: white;
    padding: 8px 8px;
    margin: 10px 5px;
    cursor: pointer;
    width: 20%;
    border:1px solid black;
font-family: basic;
font-size: 18px;}
button:hover{
    background-color:limegreen;
    color:black; 
    }

.imgcontainer {
    text-align: center;
    margin: 0px 0 0 0;
}

img.avatar {
    width: 45%;
    border-radius: 100%;
	border-color:black;
}




/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
}
.signup{
        border-style:ridge;
        border:1px solid black;
    width:16%;
        background-color: limegreen;
        display: block;
     padding:5px;
    }
    .signup a{
        text-decoration: none;
    font-size: 15px;
    color:black;
    }
    
</style>
<body>


<center>
    <body><div class="header"><h1>TEST YOUR SKILLS!</h1></div> </br>
<form action="action_page.php" method="post">
    <h2>STUDENT LOGIN</h2>
  <div class="imgcontainer">
    <img src="http://www.sammobile.com/wp-content/themes/sammobile-4/assets/img/layout/login-avatar.png" alt="Avatar" class="avatar">
  </div>

  <div class="container">
      <br/><input type="text" name="uname" required placeholder="Username"><br/><br/>
    <input type="password" name="psw" required placeholder="Password"><br/>
        
    <button type="submit" name="submit">login</button><br/>
    <input type="checkbox"  > Remember me<br/><br/>


<span class="psw"><a href="home.htm">Forgot password?</a></span><br/><br/>
<div class="signup"><a href="register.htm">Signup</a></div><br/><br/>
</form>
</center>

</body>
</html>
    <?php
    mysqli_close($connection);
    ?>

